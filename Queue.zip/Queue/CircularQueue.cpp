#include<bits/stdc++.h>
using namespace std;

    const int maxSize = 5;
    int myQueue[maxSize];
    int front = -1, rear = -1;
    

    bool isEmpty(){
        return (front == -1 && rear == -1);
    }
    bool isFull(){
        return ((rear+1)%maxSize == front);
    }
    void enQueue(int x){
        if (isFull()){
            cout << "The queue is Full, cant insert any value" << endl; 
        }
        else if (isEmpty()){
            front = 0;
            rear = 0;
            myQueue[rear] = x;
            cout << x << " is inserted " << endl;
        }
        else{
            rear = (rear+1)%maxSize ;
            myQueue[rear] = x;
            cout << x << " is inserted " << endl;
        }
    }

    void deQueue(){
        if (isEmpty()){
            cout << "The queue is empty, cant delete any more value" << endl;
        }
        else if (front == rear){
            cout << myQueue[front] << " is dequeued" << endl;
            front = -1;
            rear = -1;
        }
        else{
            cout << myQueue[front] <<  " is dequeued" << endl;
            front=(front+1)%maxSize;
        }
    }

    int frontElement (){
        return myQueue[front];
    }

    void showqueue(){
        if (isEmpty()){
            cout << "The queue is empty, cant show the full queue" << endl;
        }
        else{
            cout << "Queue Elements are: ";
            if (front <= rear){
                for (int i=front; i<=rear; i++){
                    cout << myQueue[i] << " " ;
                }
            }
            else{
                for (int i=front; i<maxSize; i++)
                    cout << myQueue[i] << " ";
                for (int i=0; i<=rear; i++)
                    cout << myQueue[i] << " ";
            }
            cout << endl;
        }
    }



int main(){

    enQueue(10);
    enQueue(20);
    enQueue(30);
    enQueue(40);
    enQueue(50);
    deQueue();
    enQueue(60);
    showqueue();

    // deQueue();
    // deQueue();
    // deQueue();
    // deQueue();
    // deQueue();
    // deQueue();
    // showqueue();

    // enQueue(100);
    // showqueue();
    // frontElement();
    // deQueue();
    // showqueue();


    
    return 0;
}