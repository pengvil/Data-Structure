#include<bits/stdc++.h>
using namespace std;

class Node{
    public: 
        int val;
        Node* next;
        Node* prev;
        Node(int val){
            this->val = val;
            this->next = NULL;
            this->prev = NULL;
        }
};

void insert_at_head(Node* &head, Node* &tail, int val){
    Node* newnode = new Node(val);
    if(head == NULL){
        head = newnode;
        tail = newnode;
        return;
    }
    newnode->next = head;
    head->prev = newnode;
    head = newnode;
}

void insert_at_any_position(Node* &head, int index, int val){
    Node* newnode = new Node(val);
    Node* tmp = head;
    for(int i=1; i<index; i++){
        tmp = tmp->next;
    }
    newnode->next = tmp->next;
    tmp->next->prev = newnode;
    tmp->next = newnode;
    newnode->prev = tmp;
}

void insert_at_tail(Node* &head, Node* &tail, int val){
    Node* newnode = new Node(val);
    if(head == NULL){
        head = newnode;
        tail = newnode;
        return;
    }
    tail->next = newnode;
    newnode->prev = tail;
    tail = newnode;
}


void delete_at_head(Node* &head, Node* &tail){
    Node* deleteNode = head;
    head = head->next;      // Shifting the head to the next one
    delete deleteNode;      // deleting the previous head
    if(head == NULL){       // only if there is one node in the linked list
        tail = NULL;
        return;
    }
    head->prev = NULL;
}

void delete_at_tail(Node* &head, Node* &tail){
    
    Node* deleteNode = tail;
    tail = tail->prev;
    delete deleteNode;
    if(tail == NULL){
        head = NULL;
        return;
    }
    tail->next = NULL;
}

void delete_at_any_position(Node* &head, int index){
    Node* tmp = head;
    for(int i=1; i<index; i++){
        tmp = tmp->next;
    }

    Node* deleteNode = tmp->next;
    tmp->next = deleteNode->next;
    tmp->next->prev = tmp;
    delete deleteNode;
}

void print_linked_list(Node* head){
    Node* tmp = head;
    while(tmp != NULL){
        cout << tmp->val << " " ;
        tmp = tmp->next ;
    }
    cout << endl;
}

int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    Node* head = new Node(10);
    Node* a = new Node(20);
    Node* tail = new Node(30);
    
    head->next = a;
    a->prev = head;

    a->next = tail;
    tail->prev = a;
    
    insert_at_any_position(head, 1, 100);
    insert_at_any_position(head, 2, 200);
    print_linked_list(head);
    delete_at_any_position(head,1);
    print_linked_list(head);
    return 0;
}